jw 1/26/10

swapped urls, manual url fixing on 2009/5 and 2009/10 entries

some manual html cleaning on lauren's posts