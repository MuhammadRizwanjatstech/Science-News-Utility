posts-a: 968 entries
posts-a-sup: 6 entries
posts-rd: 73 entries

jw 1/26/10
these entries have been authored, cleaned. still need to fix urls, but will do that after import
